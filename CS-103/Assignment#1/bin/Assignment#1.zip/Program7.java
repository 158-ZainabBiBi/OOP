public class Program7 
{
	public static void main(String[] args) 
	{
		byte var1=10;  
		byte var2=10;    
		byte var3=(byte)(var1+var2);  
		System.out.println("Byte:" +var3); 
	}
}