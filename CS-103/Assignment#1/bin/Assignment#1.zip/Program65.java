public class Program65 
{
	public static void main(String[] args) 
	{
		/* Documentation 
		   Comment 
		   in JAVA. */  
		int variable=20;  
		System.out.println(variable); 
	}
}