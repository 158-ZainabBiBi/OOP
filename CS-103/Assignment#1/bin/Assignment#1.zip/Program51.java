public class Program51 
{
	public static void main(String[] args) 
	{
		int i=0;  
	    do
	    {  
	        System.out.println(2+i);  
	        i++;  
	    }
	    while(i<=8);  
	}
}