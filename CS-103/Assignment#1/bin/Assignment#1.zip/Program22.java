public class Program22 
{

	public static void main(String[] args) 
	{
		int var1=10;  
		var1+=3;//10+3  
		System.out.println("Variable1 after Adding: " +var1);  
		var1-=4;//13-4  
		System.out.println("Variable1 after Difference: " +var1); 
		var1*=2;//9*2  
		System.out.println("Variable1 after Multiplication: " +var1);  
		var1/=2;//18/2  
		System.out.println("Variable1 after Division: " +var1);  
	}
}
