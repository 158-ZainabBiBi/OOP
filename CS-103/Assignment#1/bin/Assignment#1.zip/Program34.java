public class Program34 
{
	public static void main(String[] args) 
	{  
	    char alphabet='A';    
	    String monthString="";  
	    switch(alphabet)
	    {    
	       case 'A': 
	    	  monthString="Vowel"; 
	          break;    
	       case 'a': 
	    	  monthString="Vowel";  
	          break;    
	       case 'E': 
	    	  monthString="Vowel"; 
	          break;    
	       case 'e': 
	    	  monthString="Vowel"; 
	        break;    
	       case 'I': 
	    	  monthString="Vowel";  
	          break;    
	       case 'i': 
	    	  monthString="Vowel";  
	          break;    
	       case 'O': 
	    	  monthString="Vowel";  
	          break;    
	       case 'o': 
	    	  monthString="Vowel";    
	          break;    
	       case 'U': 
	    	  monthString="Vowel";   
	          break;    
	       case 'u': 
	    	  monthString="Vowel";  
	          break;    
	       default:
	    	  System.out.println("Consonant");    
	    }     
	    System.out.println(monthString);  
	}
}