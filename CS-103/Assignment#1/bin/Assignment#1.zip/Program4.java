public class Program4 
{  
   public static void main(String[] args)
   {  
      int var1=10;  
      float var2=var1;  
      System.out.println("Integer Variable: " +var1);  
      System.out.println("Float Variable: " +var2);  
   }
}  