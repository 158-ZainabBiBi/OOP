public class Program6 
{
	public static void main(String[] args) 
	{
		int var1=130;  
		byte var2=(byte)var1;  
		System.out.println("Integer:" +var1);  
		System.out.println("Byte:" +var2);
	}
} 