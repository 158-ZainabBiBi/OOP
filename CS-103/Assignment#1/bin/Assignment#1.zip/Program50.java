public class Program50 
{
	public static void main(String[] args) 
	{
		while(true)
		{   System.out.println("infinitive while loop");   }  
	}
}