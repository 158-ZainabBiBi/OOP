public class Program53 
{
	public static void main(String[] args) 
	{
	    for(int i=0;i<=30;i++)
	    {  
	        if(i==25)
	        {   break;  }  
	        System.out.println(i+" March ");  
	    } 
	}
}
