public class Program66 
{
	public static void main(String[] args) 
	{
		// Single-Line Comment in JAVA.  
		int variable=25;  
		System.out.println(variable); 
	}
}