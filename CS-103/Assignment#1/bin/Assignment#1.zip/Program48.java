public class Program48
{
	public static void main(String[] args) 
	{ 
	    for(;;)
	       {   System.out.println("infinitive loop");  }  
	}
}