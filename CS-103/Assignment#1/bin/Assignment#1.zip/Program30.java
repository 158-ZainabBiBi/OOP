public class Program30 
{
	public static void main(String[] args) 
	{
		int number=-13;    
	    if(number>0)
	       {   System.out.println("Given no. is Positive");   }
	    else if(number<0)
	       {   System.out.println("Given no. is Negative");   }
	    else
	       {   System.out.println("Given no. is Zero");   }  
	}
}