public class Program19 
{
	public static void main(String[] args) 
	{
		int var1=2;  
		int var2=5;  
		int min=(var1<var2)?var1:var2;  
		System.out.println("Minium no.=" +min);
	}
}