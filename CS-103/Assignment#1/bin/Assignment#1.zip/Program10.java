public class Program10 
{
	public static void main(String[] args) 
	{
		int var1=10;  
		int var2=-10;  
		boolean var3=true;  
		boolean var4=false;  
		System.out.println("Variable1:" +~var1);  
		System.out.println("Variable2:" +~var2);  
		System.out.println("Variable3:" +!var3); 
		System.out.println("Variable4:" +!var4); 
	}
}