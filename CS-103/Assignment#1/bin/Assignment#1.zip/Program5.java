public class Program5 
{
	public static void main(String[] args) 
	{
		float var1=10.5f;    
		int var2=(int)var1;  
		System.out.println("Float:" +var1);  
		System.out.println("Integer:" +var2);
	}
} 