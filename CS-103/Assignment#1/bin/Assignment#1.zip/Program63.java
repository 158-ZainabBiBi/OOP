public class Program63 
{
	public static void main(String[] args) 
	{ 
		int var1=20,var2=30;
		float var3;
		var3 = var1 + var2;
	    System.out.println("Sum = " +var3); 
	}
}