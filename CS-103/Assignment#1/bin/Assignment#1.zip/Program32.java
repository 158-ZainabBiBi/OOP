public class Program32 
{
	public static void main(String[] args) 
	{ 
	    int age=20;    
	    int weight=56;        
	    if(age>=16)
	    {      
	       if(weight>60)
	          {    System.out.println("You are eligible to donate blood");    } 
	       else
	          {   System.out.println("You are not eligible to donate blood");    }  
	    } 
	    else
	       {   System.out.println("Age must be greater than 16");   }  
	}
}