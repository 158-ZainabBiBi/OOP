public class Program15 
{
	public static void main(String[] args) 
	{
		System.out.print("Shift for positive no.");
	    System.out.println(20>>2);  
	    System.out.print("Shift for negative no.");
	    System.out.println(-20>>2);  
	}
}