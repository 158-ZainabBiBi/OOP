public class Program14 
{
	public static void main(String[] args) 
	{
		System.out.println("Right Shift Operator"); 
		System.out.println(10>>2);//10/2^2=10/4=2  
		System.out.println(20>>2);//20/2^2=20/4=5  
		System.out.println(20>>3);//20/2^3=20/8=2  
	}
}