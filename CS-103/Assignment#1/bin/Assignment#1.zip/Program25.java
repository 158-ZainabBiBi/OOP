public class Program25 
{
   public static void main(String[] args) 
   {     
	  int age=19;   
	  if(age>16)
	  {  System.out.print("Age is greater than 16");  }  
   }
}
