public class Program21 
{
	public static void main(String[] args) 
	{
		int var1=10;  
		int var2=20;  
		var1+=4;//a=a+4 (a=10+4)  
		var2-=4;//b=b-4 (b=20-4)  
		System.out.println("Variable1: " +var1);  
		System.out.println("Variable2: " +var2); 
	}
}
