public class Program45
{
	public static void main(String[] args) 
	{  
	    int array[]={3,6,9,12,15,18,21,24,27,30};
	    for(int i:array)
	    {   System.out.println(i);   }  
	}
}