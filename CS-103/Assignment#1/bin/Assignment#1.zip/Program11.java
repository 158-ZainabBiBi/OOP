public class Program11 
{
	public static void main(String[] args) 
	{
		int var1=10;  
		int var2=5;  
		System.out.println("Sum: " +var1+var2);//15    
		System.out.println("Multiply: " +var1*var2);//50  
		System.out.println("Divison: " +var1/var2);//2  
	}
}