public class Program2 
{
	int var1=50;//instance variable  
	static int var2=100;//static variable 
    public static void main(String[] args) 
	{
    	int var3=90;//local variable
        System.out.println("Static Variable: " +var2);
        System.out.println("Local Variable: " +var3);
	}
}