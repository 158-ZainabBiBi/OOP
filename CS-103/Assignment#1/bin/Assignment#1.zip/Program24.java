public class Program24 
{
	public static void main(String[] args) 
	{
		short var1=10;  
		short var2=20;  
		var1=(short)(var1+var2);//20 which is int now converted to short  
		System.out.println("Variable1 after Adding: " +var1); 
	}
}
