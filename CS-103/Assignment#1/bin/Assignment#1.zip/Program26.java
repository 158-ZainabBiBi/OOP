public class Program26 
{
	public static void main(String[] args) 
	{  
	    int number=13;    
	    if(number%2==0)
	    {   System.out.println("Given no. is Even");   }
	    else
	    {   System.out.println("Given no. is Odd");   }  
	}
}
