public class Program3 
{  
	public static void main(String[] args)
	{  
	    int var1=10;  
	    int var2=10;  
	    int var3=var1+var2;  
	    System.out.println("Sum = " +var3);  
	}
} 