public class Program9 
{
	public static void main(String[] args) 
	{
		int var1=10;  
		int var2=10;  
		System.out.println("Postfix & Prefix var1: "+ var1++ + ++var1); 
		System.out.println("Postfix & Prefix var2: "+ var2++ + ++var2);
	}
} 