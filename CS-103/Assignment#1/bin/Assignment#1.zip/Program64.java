public class Program64 
{
	public static void main(String[] args) 
	{
		/* Multi-Line 
		   Comment 
		   in JAVA. */  
		int variable=25;  
		System.out.println(variable); 
	}
}