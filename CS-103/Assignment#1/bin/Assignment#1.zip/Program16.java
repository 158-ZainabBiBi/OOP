public class Program16 
{
	public static void main(String[] args) 
	{
		int var1=10;  
		int var2=5;  
		int var3=20;  
		System.out.print("Condition: ");
		System.out.println(var1<var2&&var1<var3);
	}
}
